public interface ScoreDisplay
{
  void update(int score);
}
