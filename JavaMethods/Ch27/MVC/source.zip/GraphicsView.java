import java.awt.Graphics;
import java.awt.Color;
import javax.swing.JPanel;
import java.util.Observer;
import java.util.Observable;

/**
 * Model-View-Controller example:
 * implements the "graphics" view in the MVC sphere demo.
 */
public class GraphicsView extends JPanel
    implements Observer
{
  private int radius;

  public GraphicsView()
  {
    setBackground(Color.WHITE);
  }

  public void paintComponent(Graphics g)
  {
    super.paintComponent(g);

    if (radius == 0)
      return;

    g.setColor(Color.BLUE);
    int x0 = getWidth() / 2;
    int y0 = getHeight() / 2;
    g.drawOval(x0 - radius, y0 - radius, 2*radius, 2*radius);
    g.drawOval(x0 - radius / 2, y0 - radius, radius, 2*radius);
    g.drawOval(x0 - radius, y0 - radius / 4, 2 * radius, radius / 2);
  }

  public void update(Observable obj, Object arg)
  {
    Sphere sphere = (Sphere)obj;
    radius =  (int)sphere.getRadius();
    repaint();
  }
}
