import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.util.Observer;
import java.util.Observable;

/**
 * Model-View-Controller example:
 * implements the "text" view in the MVC sphere demo.
 */
public class TextView extends JPanel
    implements Observer
{
  private JTextField radiusInput, volumeDisplay, surfAreaDisplay;

  public TextView()
  {
    setLayout(new GridLayout(6, 2, 10, 10));
    setBorder(new EmptyBorder(10, 10, 10, 10));

    add(new JLabel("Radius = ", JLabel.RIGHT));

    radiusInput = new JTextField(8);
    radiusInput.setBackground(Color.YELLOW);
    add(radiusInput);

    add(new JLabel("Volume = ", JLabel.RIGHT));

    volumeDisplay = new JTextField(8);
    volumeDisplay.setEditable(false);
    volumeDisplay.setBackground(Color.WHITE);
    add(volumeDisplay);

    add(new JLabel("Surface area = ", JLabel.RIGHT));

    surfAreaDisplay = new JTextField(8);
    surfAreaDisplay.setEditable(false);
    surfAreaDisplay.setBackground(Color.WHITE);
    add(surfAreaDisplay);

    add (new JPanel()); // Not used
  }

  public void addActionListener(ActionListener listener)
  {
    radiusInput.addActionListener(listener);
  }

  public void update(Observable obj, Object arg)
  {
    Sphere sphere = (Sphere)obj;
    radiusInput.setText(String.format(" %.1f", sphere.getRadius()));
    volumeDisplay.setText(String.format(" %5.1f", sphere.volume()));
    surfAreaDisplay.setText(String.format(" %5.1f", sphere.surfaceArea()));
  }
}
